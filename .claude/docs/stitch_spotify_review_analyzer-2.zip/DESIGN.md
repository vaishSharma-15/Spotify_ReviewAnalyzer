---
name: Sonic Intelligence
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#bccbb9'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#869585'
  outline-variant: '#3d4a3d'
  surface-tint: '#53e076'
  primary: '#53e076'
  on-primary: '#003914'
  primary-container: '#1db954'
  on-primary-container: '#004118'
  inverse-primary: '#006e2d'
  secondary: '#c8c6c5'
  on-secondary: '#303030'
  secondary-container: '#474746'
  on-secondary-container: '#b7b5b4'
  tertiary: '#c8c6c6'
  on-tertiary: '#303030'
  tertiary-container: '#a2a1a1'
  on-tertiary-container: '#383838'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#72fe8f'
  primary-fixed-dim: '#53e076'
  on-primary-fixed: '#002108'
  on-primary-fixed-variant: '#005320'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e4e2e2'
  tertiary-fixed-dim: '#c8c6c6'
  on-tertiary-fixed: '#1b1c1c'
  on-tertiary-fixed-variant: '#474747'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-bold:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-margin: 16px
  gutter: 12px
  bubble-padding: 12px 16px
  stack-gap: 8px
---

## Brand & Style

The design system is engineered for a data-driven chatbot that feels like an extension of a premium audio ecosystem. The personality is energetic yet focused—leveraging the high-contrast "Dark Mode" aesthetic to make data visualizations and chat bubbles pop with clarity.

The visual style is a fusion of **Modern Corporate** and **High-Contrast Digital**. It utilizes deep obsidian backgrounds to create an infinite sense of depth, allowing the signature green to act as a functional beacon for primary actions. The interface is mobile-first, prioritizing thumb-friendly hit targets and a dense but legible information hierarchy that suits a data-heavy conversational agent.

## Colors

The palette is anchored in a true dark-theme philosophy. 

- **Primary Green (#1DB954):** Used exclusively for high-intent actions, progress indicators, and active states.
- **Surface Tiers:** The base background is `#121212`. Secondary surfaces like chat bubbles or card backgrounds use `#191414` or `#212121` to create subtle elevation.
- **Typography:** Pure White (`#FFFFFF`) is reserved for headlines and primary input. Medium Grey (`#B3B3B3`) is used for secondary metadata and timestamps to reduce eye strain during long chat sessions.

## Typography

This design system uses **Plus Jakarta Sans** as a contemporary, high-legibility alternative to Gotham. It maintains the geometric "O" and open apertures necessary for clarity on mobile screens.

- **Headlines:** Use Bold or ExtraBold weights with slight negative letter spacing to create a compact, "editorial" feel.
- **Chat Bubbles:** Utilize `body-md` for standard messages to maximize content density without sacrificing readability.
- **Labels:** Small caps or increased letter spacing should be applied to `label-bold` for category tags or data headers to differentiate them from conversational text.

## Layout & Spacing

The layout follows a **4px baseline grid** to ensure mathematical consistency across mobile devices. 

- **Chat Interface:** A fluid vertical stack with a standard 16px margin on the left and right edges. 
- **Data Grids:** For chatbot responses involving tables or charts, use a 12px gutter to keep information dense but distinct.
- **Mobile-First Constraints:** All interactive elements (buttons, chips) must maintain a minimum height of 44px to accommodate touch input, regardless of their visual font size.

## Elevation & Depth

Depth is communicated through **Tonal Layering** rather than traditional drop shadows. In a dark UI, shadows are often invisible; therefore, brightness defines height.

- **Level 0 (Floor):** `#121212` - Main application background.
- **Level 1 (Bubbles/Cards):** `#191414` - User messages and standard response cards.
- **Level 2 (Modals/Popovers):** `#282828` - Elements that require immediate attention.
- **Accents:** Use 1px inner borders (strokes) with 10% white opacity on cards to define edges against the black background, creating a crisp, premium feel.

## Shapes

The shape language is friendly but structured. A standard **8px (0.5rem)** radius is applied to most containers.

- **Chat Bubbles:** User bubbles feature a higher roundedness on three corners with a sharper point on the directional corner.
- **Action Buttons:** Utilize fully pill-shaped (rounded-full) geometry to mirror the iconic "Play" button aesthetic.
- **Data Visualizations:** Bar charts and progress rings should use rounded end-caps to maintain the soft-geometric theme.

## Components

### Buttons
- **Primary:** Pill-shaped, Primary Green background, Black text (`#121212`), Bold weight.
- **Secondary:** Pill-shaped, White stroke (1px), Transparent background, White text.

### Chat Bubbles
- **User:** Primary Green background with black text. Aligned right.
- **Bot:** Secondary Surface (`#212121`) background with white text. Aligned left.
- **Data Cards:** Embedded within the bot's response stream, using a `#191414` background and subtle 1px border.

### Input Field
- Fixed to the bottom of the viewport. 
- Rounded-full container with a `#282828` background. 
- Placeholder text in Secondary Text color (`#B3B3B3`).

### Chips & Filters
- Used for suggested prompts or data filters. 
- Small, pill-shaped, `#282828` background, transitions to Primary Green stroke when active.

### Progress & Loading
- Use a "pulsing" skeleton state using the `#212121` to `#282828` gradient for data-loading sequences.